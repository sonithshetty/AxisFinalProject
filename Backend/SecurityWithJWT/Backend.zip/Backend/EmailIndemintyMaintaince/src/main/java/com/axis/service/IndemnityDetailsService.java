package com.axis.service;

public interface IndemnityDetailsService {

}
