package com.axis.service;

public interface AccountDetailsService {

}
