package com.axis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmailIndemintyMaintainceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmailIndemintyMaintainceApplication.class, args);
	}

}
