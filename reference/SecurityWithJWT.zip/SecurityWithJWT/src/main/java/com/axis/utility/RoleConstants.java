package com.axis.utility;

public class RoleConstants {

	 public static final String USER_ROLE = "ROLE_USER";
	 public static final String ADMIN_ROLE = "ROLE_ADMIN";
}
