
import { Route, Routes } from 'react-router-dom';
import './App.css';
import EmployeeHome from './Components/EmployeeComponent/EmployeeHome';
import EmployeeLogin from './Components/EmployeeComponent/EmployeeLogin';
import Home from './Components/Home';
import ManegerHome from './Components/ManegerComponent/ManegerHome';
import ManegerLogin from './Components/ManegerComponent/ManegerLogin';

function App() {
  return (
    <Routes>
      <Route path="/employeelogin" element={<EmployeeLogin/>}/>
      <Route path="/manegerlogin" element={<ManegerLogin/>}/>
      <Route path="/" element={<EmployeeHome/>}/>
      <Route path='/manegerhome' element={<ManegerHome/>}/>
    </Routes>
  );
}

export default App;
